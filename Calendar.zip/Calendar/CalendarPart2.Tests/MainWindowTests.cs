using NUnit.Framework;

namespace CalendarPart2.Tests
{
    public class Tests
    {
        private int yearNumber;

        [SetUp]
        public void Setup()
        {
            yearNumber = 1994;
        }

        [Test]
        public void GetYearNumber_yearNumber_ReturnsEqual()
        {
            MainWindow mainWindow = new MainWindow();
            int yearNumberReturned = mainWindow.GetYearNumber();
            Assert.AreEqual(yearNumber, yearNumberReturned, "Year number is not the same");

        }
        
    }
}



